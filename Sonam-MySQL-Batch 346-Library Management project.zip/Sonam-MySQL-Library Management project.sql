create database Library;
use library;

-- 1.creating publisher table
create table tbl_publisher(
publisher_publishername varchar(255) primary key, 
publisher_publisheraddress text,
publisher_publisherphone text);

-- 2.creating books table
create table tbl_book(
book_bookid int primary key auto_increment,
book_title text,
book_publishername varchar(255),
foreign key(book_publishername) references tbl_publisher(publisher_publishername)
on update cascade
on delete cascade);

-- 3.creating book_authors table
create table tbl_book_authors(
book_authors_authorid int primary key auto_increment,
book_authors_bookid int,
book_authors_authorname text,
foreign key(book_authors_bookid) references tbl_book(book_bookid)
on update cascade
on delete cascade);

-- 4.creating library branch
create table tbl_library_branch(
library_branch_branchid int primary key auto_increment,
library_branch_branchname varchar(255),
library_branch_branchaddress text);

-- 5.creating borrowers table
create table tbl_borrower(
borrower_cardno int primary key auto_increment,
borrower_borrowername varchar(255),
borrower_borroweraddress text,
borrower_borrowerphone varchar(15));

-- 6.creating table book copies
create table tbl_book_copies(
book_copies_copiesid int primary key auto_increment,
book_copies_bookid int,
book_copies_branchid int,
book_copies_no_of_copies int,
foreign key(book_copies_bookid) references tbl_book(book_bookid)
on update cascade
on delete cascade,
foreign key(book_copies_branchid) references tbl_library_branch(library_branch_branchid)
on update cascade
on delete cascade);

-- 7.creating book loans table
create table tbl_book_loans(
book_loans_loansid int primary key auto_increment,
book_loans_bookid int,
book_loans_branchid int,
book_loans_cardno int,
book_loans_dateout varchar(100),
book_loans_duedate varchar(100),
foreign key(book_loans_bookid) references tbl_book(book_bookid)
on update cascade
on delete cascade,
foreign key(book_loans_branchid) references tbl_library_branch(library_branch_branchid)
on update cascade
on delete cascade,
foreign key(book_loans_cardno) references tbl_borrower(borrower_cardno)
on update cascade
on delete cascade);

-- imported 7 files to insert values in the tables

-- changing datatype of datecolumns from varchar to date in tbl_book_loans


alter table tbl_book_loans
modify book_loans_dateout date;
-- 	Error Code: 1292. Incorrect date value: '1/15/18' for column 'book_loans_dateout' at row 37	0.140 sec

UPDATE tbl_book_loans
SET book_loans_dateout = STR_TO_DATE(book_loans_dateout, '%m/%d/%y')
WHERE STR_TO_DATE(book_loans_dateout, '%m/%d/%y') IS NOT NULL;

update tbl_book_loans
set book_loans_duedate = STR_TO_DATE(book_loans_duedate,'%m/%d/%y')
where str_to_date(book_loans_duedate,'%m/%d/%y') is not null;


-- executing the queries for given questions
-- 1)How many copies of the book titled "The Lost Tribe" are owned by the library branch whose name is "Sharpstown"?

with cte_copies as(select * from tbl_book_copies bc
join tbl_library_branch lb
on bc.book_copies_branchid=lb.library_branch_branchid
where library_branch_branchname="Sharpstown")
select book_copies_no_of_copies from cte_copies
join tbl_book tb
on cte_copies.book_copies_bookid=tb.book_bookid
where tb.book_title="The Lost Tribe";
-- no.of copies = 5 and count of no.of copies=1

-- 2)How many copies of the book titled "The Lost Tribe" are owned by each library branch?

with cte_each_branch as(select lb.library_branch_branchname,bc.book_copies_no_of_copies,bc.book_copies_bookid from tbl_book_copies bc
join tbl_library_branch lb
on bc.book_copies_branchid=lb.library_branch_branchid
group by lb.library_branch_branchname,bc.book_copies_no_of_copies,bc.book_copies_bookid)
select cte_each_branch.library_branch_branchname,cte_each_branch.book_copies_no_of_copies,tb.book_title from cte_each_branch 
join tbl_book tb
on cte_each_branch.book_copies_bookid=tb.book_bookid
where tb.book_title="The Lost Tribe"; 
-- each branch of book title the lost tribe owned 5 no.of copies with count as 1

-- 3)Retrieve the names of all borrowers who do not have any books checked out.

select * from tbl_borrower b
left join tbl_book_loans l
on b.borrower_cardno=l.book_loans_cardno
where (book_loans_dateout) is null or (book_loans_duedate) is null ;
-- Jane smith has no books checked out

-- 4)For each book that is loaned out from the "Sharpstown" branch and whose DueDate is 2/3/18, retrieve the book title, the borrower's name, and the borrower's address. 

SELECT b.book_title,br.borrower_borrowername,br.borrower_borroweraddress
FROM tbl_book b
JOIN tbl_book_loans bl ON b.book_bookid = bl.book_loans_bookid
JOIN tbl_borrower br ON bl.book_loans_cardno = br.borrower_cardno
JOIN tbl_library_branch brn ON bl.book_loans_branchid = brn.library_branch_branchid
WHERE brn.library_branch_branchname = 'Sharpstown' AND bl.book_loans_duedate = '2018-02-03';

-- 5)For each library branch, retrieve the branch name and the total number of books loaned out from that branch.
select lb.library_branch_branchname,count(book_loans_bookid) from tbl_library_branch lb
join tbl_book_loans bl
on lb.library_branch_branchid=bl.book_loans_branchid
group by lb.library_branch_branchname;

-- 6)Retrieve the names, addresses, and number of books checked out for all borrowers who have more than five books checked out.
select b.borrower_borrowername,b.borrower_borroweraddress,count(bl.book_loans_bookid) from tbl_book_loans bl
right join tbl_borrower b
on bl.book_loans_cardno=b.borrower_cardno
where bl.book_loans_bookid>5 
group by b.borrower_borrowername,b.borrower_borroweraddress;
-- Error Code: 1140. In aggregated query without GROUP BY, expression #1 of SELECT list contains nonaggregated column 'library.b.borrower_borrowername'; this is incompatible with sql_mode=only_full_group_by	0.000 sec
-- solved by using group by clause

-- 7)For each book authored by "Stephen King", retrieve the title and the number of copies owned by the library branch whose name is "Central".

select b.book_title,bc.book_copies_no_of_copies from tbl_library_branch lb
join tbl_book_copies bc
on lb.library_branch_branchid=bc.book_copies_branchid
join tbl_book b
on bc.book_copies_bookid=b.book_bookid
join tbl_book_authors ba
on b.book_bookid=ba.book_authors_bookid
where lb.library_branch_branchname="Central" and ba.book_authors_authorname="Stephen king";
-- book title It,The green mile with each 5 no.of copies and count as 1,1  

